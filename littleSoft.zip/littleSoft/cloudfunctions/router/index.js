const TcbRouter = require('tcb-router');

exports.main = async (event, context) => {
  const app = new TcbRouter({ event });

  app.router('user', async (ctx, next) => {
    ctx.body = {
      code: 0,
      message: 'register success'
    }
  });
  return app.serve();

}