const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk');
cloud.init()
exports.main = async (event, context) => {
  const app = new TcbRouter({ event });

  app.router('userLogin', async (ctx, next) => {
    const uuidv1 = require('uuid/v1');
    const db = cloud.database({});
    const cont = await db.collection('t_user').where({ open_id: ctx._req.event.userInfo.openId }).count()
    if (cont.total == 0) {
      const date = new Date(new Date().getTime() + 28800000)
      await db.collection('t_user').add({
        // data 字段表示需新增的 JSON 数据
        data: {
          "id": uuidv1(),
          "union_id": "",
          "user_name": "",
          "phone": "",
          "password": "",
          "user_type": "person",
          "state": "1",
          //"lastlogin_time": date.toLocaleDateString() + date.toLocaleTimeString(),
          "lastlogin_time": date.toLocaleDateString() + " " + date.toLocaleTimeString(),
          "open_id": ctx._req.event.userInfo.openId,
          "is_company": "0",
          "is_saleman": "0"
        }
      })
      } await next(); // 执行下一中间件
    }, async (ctx) => {
      const db = cloud.database({});
      var user = await db.collection('t_user').where({ open_id: ctx._req.event.userInfo.openId }).get()
      ctx.body = { code: 0, cont: user };
    });



  app.router('getUser', async (ctx, next) => {
    const user = await db.collection('t_user').where({ open_id: ctx._req.event.userInfo.openId }).get()
    ctx.body = {
      code: 0,
      user: user
    }
  })
  return app.serve();

}