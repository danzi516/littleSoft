const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk');
cloud.init()
exports.main = async (event, context) => {
  const app = new TcbRouter({ event });

  app.router('userLogin', async (ctx, next) => {
    const uuidv1 = require('uuid/v1');
    const db = cloud.database({});
    const cont = await db.collection('t_user').where({ open_id: ctx._req.event.userInfo.openId }).count()
    if (cont.total == 0) {
      const date = new Date(new Date().getTime() + 28800000)
      await db.collection('t_user').add({
        // data 字段表示需新增的 JSON 数据
        data: {
          "id": uuidv1(),
          "union_id": "",
          "user_name": "",
          "phone": "",
          "password": "",
          "user_type": "person",
          "state": "1",
          //"lastlogin_time": date.toLocaleDateString() + date.toLocaleTimeString(),
          "lastlogin_time": date.toLocaleDateString() + " " + date.toLocaleTimeString(),
          "open_id": ctx._req.event.userInfo.openId,
          "is_company": "0",
          "is_saleman": "0",
          "membership_card":(Math.random() * 10000000).toString(16).substr(0, 4) + '-' + (new Date()).getTime() + '-' + Math.random().toString().substr(2, 5)
        }
      })
      } await next(); // 执行下一中间件
    }, async (ctx) => {
      const db = cloud.database({});
      var user = await db.collection('t_user').where({ open_id: ctx._req.event.userInfo.openId }).get()
      ctx.body = { code: 0, cont: user };
    });



  app.router('getUserByKey', async (ctx, next) => {
    // const user = await db.collection('t_user').where({}).get()
    const db = cloud.database({});
    const _ = db.command
    const userList = await db.collection('t_user').where(_.or([
      {
        user_name: db.RegExp({
          regexp: '.*' + ctx._req.event.keyword,
          options: 'i'
        })},
      {
        phone: db.RegExp({
          regexp: '.*' + ctx._req.event.keyword,
          options: 'i'
        })
      },
      {
        membership_card: db.RegExp({
          regexp: '.*' + ctx._req.event.keyword,
          options: 'i'
        })
      }
    ])).get()


    // const userList = await db.collection('t_user').where(
    //   {
    //     phone: db.RegExp({
    //       regexp:  ctx._req.event.keyword ,
    //       options: 'i'
    //     })}).get()
    ctx.body = {
      code: 0,
      userList: userList
    }
  })
  return app.serve();

}