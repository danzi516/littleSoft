// 云函数入口文件
const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk')
cloud.init()

exports.main = async (event, context) => {
  const app = new TcbRouter({ event });
  app.router('addShopMember', async (ctx, next) => {
    const uuidv1 = require('uuid/v1');
    const date = new Date(new Date().getTime() + 28800000)
    let dateTime = date.toLocaleDateString() + " " + date.toLocaleTimeString()
    var code=1
    const db = cloud.database({});
    const cont = await db.collection('t_company_member').where({ company_id: ctx._req.event.id, user_id: ctx._req.event.userId}).count()
    if (cont.total == 0) {
      await db.collection('t_company_member').add({
        data: {
          id: uuidv1(),
          cash: '0',
          company_id: ctx._req.event.id,
          user_id: ctx._req.event.userId,
          creatTime: dateTime,
          isState:'1',
          remark:'',
          member_type:'0',
          membership_card: ctx._req.event.membership_card
        }
      })
      code = 0
    }
    ctx.body = {
      code: code
      //openId: ctx._req.event.userInfo.openId
    }
  });

    app.router('getShopMember', async (ctx, next) => {
      const db = cloud.database({});
      const _ = db.command
      const cont = await db.collection('t_company_member').where({ company_id: ctx._req.event.id }).field({
        user_id: true
      }).get().then(({ data }) => {
        return db.collection('t_user').where({
          id: _.in(data.map(item => item.user_id)),
        }).get();
      })
      ctx.body = {
        code: 0,
        cont: cont
      }
    })

  return app.serve();
}