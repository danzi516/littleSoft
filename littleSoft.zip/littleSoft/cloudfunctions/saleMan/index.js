const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk');
cloud.init()
exports.main = async (event, context) => {
  const app = new TcbRouter({ event });
  //查询数据
  app.router('getSaleMan', async (ctx, next) => {
    const db = cloud.database({});
    const cont = await db.collection('t_saleman').where({ id: ctx._req.event.userInfo.openId, state: ctx._req.event.state }).get()
    ctx.body = { code: 0, cont:cont };
  })
  //新增数据
  app.router('applySaleMan', async (ctx, next) => {
    const db = cloud.database({}); 
    const date = new Date(new Date().getTime() + 28800000)
    await db.collection('t_saleman').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        "id": ctx._req.event.id,
        "invitation_code": "",
        "state": "1",
        "register_time": date.toLocaleDateString() + " " + date.toLocaleTimeString()
      }
    });await next();}, async (ctx, next) => {
      const db = cloud.database({});
      await db.collection('t_user').where({ id: ctx._req.event.id}).update({data: {is_saleman: '1'},})
        await next(); // 执行下一中间件
    },async (ctx) => {
    const db = cloud.database({});
      var cont = await db.collection('t_user').where({ id: ctx._req.event.id }).get()
    ctx.body = { code: 0, cont: cont }})
  return app.serve();
}