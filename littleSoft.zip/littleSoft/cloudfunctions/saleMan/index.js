const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk');
cloud.init()
exports.main = async (event, context) => {
  const app = new TcbRouter({ event });
  //查询数据
  app.router('getSaleMan', async (ctx, next) => {
    const db = cloud.database({});
    const cont = await db.collection('t_saleman').where({ id: ctx._req.event.userInfo.openId, state: ctx._req.event.state }).get()
    ctx.body = { code: 0, cont:cont };
  })
  //新增数据
  app.router('applySaleMan', async (ctx, next) => {
    const db = cloud.database({}); 
    const date = new Date(new Date().getTime() + 28800000)
    await db.collection('t_saleman').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        "id": ctx._req.event.id,
        "invitation_code": "",
        "state": "1",
        "register_time": date.toLocaleDateString() + " " + date.toLocaleTimeString()
      }
    });await next();}, async (ctx, next) => {
      const db = cloud.database({});
      await db.collection('t_user').where({ id: ctx._req.event.id}).update({data: {is_saleman: '1'},})
        await next(); // 执行下一中间件
    },async (ctx) => {
    const db = cloud.database({});
      var cont = await db.collection('t_user').where({ id: ctx._req.event.id }).get()
    ctx.body = { code: 0, cont: cont }})

  //获取业绩-对应的商户
  app.router('getSaleManCompany', async (ctx, next) => {
    const db = cloud.database()
    const _ = db.command
    const cont = await db.collection('t_saleman_company').where({
      saleman_id: ctx._req.event.id,
    }).field({
      company_id: true,
    }).get().then(({data}) => {
        return db.collection('t_company_info').where({
          id: _.in(data.map(item => item.company_id)),
      }).get();
      })
    ctx.body = { code: 0, cont: cont }
    }
    )

  //获取邀请码
  app.router('getInvitationCode', async (ctx, next) => {
    var forState = true
    var invitationCode = Math.round(Math.random() * 100000);
    var list =[]
    const db = cloud.database({});
    const cont = await db.collection('t_reg_verification').where({ saleman_id: ctx._req.event.id, state:"0" }).count()
    if (cont.total == 0) {
      while (forState) {
        list.push(invitationCode)
        const cont2 = await db.collection('t_reg_verification').where({ invitation_code: invitationCode, state: "0" }).count()
        if (cont2.total == 0) {
          forState = false
        }
        else {
          invitationCode = Math.round(Math.random() * 100000);
        }
      }

      const date = new Date(new Date().getTime() + 28800000)
      await db.collection('t_reg_verification').add({
        data: {
          "saleman_id": ctx._req.event.id,
          "invitation_code": invitationCode,
          "state": "0",
          "creat_time": date.toLocaleDateString() + " " + date.toLocaleTimeString(),
          "update_time": ""
        }
      })
    } await next();
  }, async (ctx) => {
    const db = cloud.database({});
    var data = await db.collection('t_reg_verification').where({ saleman_id: ctx._req.event.id, state: "0" }).get()
    ctx.body = { code: 0, cont: data };
  })

  return app.serve();
}