const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk')
cloud.init()
exports.main = async (event, context) => {
  const app = new TcbRouter({ event });

  app.router('selectCompanyAllList', async (ctx, next) => {
    const db = cloud.database({});
    const cont = await db.collection('t_company_info').get()
    ctx.body = {
      code: 0,
      cont: cont
      //openId: ctx._req.event.userInfo.openId
    }
  });
  return app.serve();

}