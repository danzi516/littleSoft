const TcbRouter = require('tcb-router');
const cloud = require('wx-server-sdk')
cloud.init()
exports.main = async (event, context) => {
  const app = new TcbRouter({ event });

  app.router('selectCompanyAllList', async (ctx, next) => {
    const db = cloud.database({});
    const cont = await db.collection('t_company_info').where({ userId: ctx._req.event.userId, isState: ctx._req.event.isState }).orderBy('isState', 'desc').get()
    const shortName = await db.collection('t_company_info').field({shopShortName:true}).where({ userId: ctx._req.event.userId, isState: ctx._req.event.isState }).orderBy('isState', 'desc').get()
    ctx.body = {
      code: 0,
      cont: cont,
      shortName: shortName
      //openId: ctx._req.event.userInfo.openId
    }
  });

  app.router('verifyCode', async (ctx, next) => {
    
    const db = cloud.database({});
    const cont = await db.collection('t_reg_verification').field({ saleman_id: true }).where({ invitation_code: Number(ctx._req.event.invitation_code), state: "0" }).get()
    if (cont.data.length != 0) {
      ctx.body = {
        code: 0,
        cont: cont
        //openId: ctx._req.event.userInfo.openId
      }
    }else{
      ctx.body = {
        code: 1
      }
    }
    
  });

  app.router('addCompany', async (ctx, next) => {
    const db = cloud.database({});
    const uuidv1 = require('uuid/v1');
    const uuid = uuidv1()
    const date = new Date(new Date().getTime() + 28800000)
    let dateTime = date.toLocaleDateString() + " " + date.toLocaleTimeString()
    try{
      await db.collection('t_reg_verification').doc(ctx._req.event.data.regVerificationId).update({ data: { state: "1" } })
      await db.collection('t_saleman_company').add({ data: { "company_id": uuid, "saleman_id": ctx._req.event.data.saleman_id, "creat_time": dateTime } })
      await db.collection('t_company_info').add({
        data: {
          "address": ctx._req.event.data.address,
          "businessCate": ctx._req.event.data.businessCate,
          "city": ctx._req.event.data.city,
          "doorPic": ctx._req.event.data.doorPic,
          "healthPic": ctx._req.event.data.healthPic,
          "licensePic": ctx._req.event.data.licensePic,
          "link_person": ctx._req.event.data.link_person,
          "locationX": ctx._req.event.data.locationX,
          "locationY": ctx._req.event.data.locationY,
          "mobile": ctx._req.event.data.mobile,
          "shopName": ctx._req.event.data.shopName,
          "shopShortName": ctx._req.event.data.shopShortName,
          "userId": ctx._req.event.data.userId,
          "id": uuid,
          "isState": "0",
          "memberConfirm":"0",
          "creatTime": dateTime
        }
      })
      ctx.body = {
        code: 0,
        company_id: uuid
      //openId: ctx._req.event.userInfo.openId

    }
    }
      catch(e){
      ctx.body = {
        code: 1
      //openId: ctx._req.event.userInfo.openId}
    }}   
  });
  app.router('updateCompany', async (ctx, next) => {
    const db = cloud.database({});
    const cont = await db.collection('t_company_info').where({ id: ctx._req.event.data.id}).update({ 
      data: {
        address: ctx._req.event.data.address,
        businessCate: ctx._req.event.data.businessCate,
        city: ctx._req.event.data.city,
        doorPic: ctx._req.event.data.doorPic,
        locationX: ctx._req.event.data.locationX,
        locationY: ctx._req.event.data.locationY,
        memberConfirm: ctx._req.event.data.memberConfirm,
        mobile: ctx._req.event.data.mobile,
        link_person: ctx._req.event.data.link_person,
        userId: ctx._req.event.data.userId
      } 
      })
    ctx.body = {
      code: 0,
      cont: cont
      //openId: ctx._req.event.userInfo.openId
    }
  });




  return app.serve();

}