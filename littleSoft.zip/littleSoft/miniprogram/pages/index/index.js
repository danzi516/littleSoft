//index.js 
import Api from '/../../utils/config/api.js';

import {
  GLOBAL_API_DOMAIN
} from '/../../utils/config/config.js';
var utils = require('../../utils/util.js');
import { req } from '../../utils/config/api.js'
const app = getApp();
var userId;
Page({
  data: {
    _build_url: GLOBAL_API_DOMAIN,
    city: "",
    phone: '',
    verify: '', //输入的验证码
    verifyId: '', //后台返回的短信验证码
    veridyTime: '', //短信发送时间
    carousel: [], //轮播图
    business: [], //商家列表，推荐餐厅
    actlist: [], //热门活动
    hotlive: [], //热门直播
    food: [], //美食墙
    logs: [],
    topics: [], //专题
    restaurant: [], //菜系专题
    service: [], //服务专题
    alltopics: [],
    currentTab: 0,
    issnap: false, //是否是临时用户
    isNew: false, //是否新用户
    userGiftFlag: false, //新用户礼包是否隐藏
    isphoneNumber: false, //是否拿到手机号
    isfirst: false,
    istouqu: false,
    isclose: false,
    goto: false,
    navbar: ['菜系专题', '服务专题'],
    sort: ['川湘菜', '海鲜', '火锅', '烧烤', '西餐', '自助餐', '聚会', '商务', '约会'],
    activityImg: '', //活动图
    settime: null,
    rematime: '获取验证码',
    afirst: false,
    isclick: true,
    newGoods: [],
    resBaseUrl:"",                // 地址
    todayTime: 0,                 // 今天日期
    tabIndex: 0,                  // tab切换
    apiStatus: 0,                 // 顺序加载
    isCompany:0,
    isSaleman:0
  },
  onLoad() {
    // 调用云函数，获取openid
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)

        app.globalData.openid = res.result.openid
  
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        
      }
    })
      //获取所有商家信息
      wx.cloud.callFunction({
        name: 'companyInfo',
        data: {
          $url: 'selectCompanyAllList'
        }
      }).then(res => {
        console.log(res.result)
        this.setData({
          tabIndex: 0,
          newGoods: res.result.list,
          apiStatus: this.data.apiStatus + 1,
          resBaseUrl: app.globalData.bastUrl
        })
      }).catch(err => {
        console.log(err)
      })
  },
  onShow() {
    //获取用户信息
    this.userLogin()
  },
  // 顶部tab切换
  tabtap: function (e) {
    let that = this
    // tab切换
    let id = e.target.dataset.id
    this.setData({
      tabIndex: id,
      categoriesTabIndex: id
    })
    // 设置滚动条在顶部
    this.returnTop()
    // 切换到商店直接返回
    if (id == 0) return
    // // 赋值子分类
    // this.data.categories.forEach(function (value) {
    //   if (value.id == id) {
    //     that.setData({
    //       categoriesChild: value.children
    //     })
    //   }
    // })
    // // 切换到新的
    // this.clearcategoriesGoods()
    // // 分类关联商品
    // this.getcategoriesGoods()
  },
  // 返回顶部
  returnTop: function () {
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    })
  },
  
  userLogin(){
    // 调用云函数,判断是否注册
    wx.cloud.callFunction({
      name: 'user',
      data: {
        $url: 'userLogin'
      },
      success: res => {
        console.log(res);
        app.globalData.isCompany = res.result.result.data[0].is_company;
        app.globalData.isSaleman = res.result.result.data[0].is_saleman;
        app.globalData.userType = res.result.result.data[0].user_type
      },
      fail: err => {
        wx.showToast({
          title: '系统出错了哦！',
          duration: 2000
        })
      }
    })
  },
  editCompanyInfo: function () {

  },
  
  applySaleMan: function () {
    wx.request({
      url: "http://127.0.0.1:8080/littledevil/wxpay/applySaleMan",
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      method: "POST",
      data: {
        salemanId: parseInt(userId)
      },
      success: (res) => {
        console.log(res)

      }
    })
  },
  getInvitationCode:function(){
    wx.request({
      url: "http://127.0.0.1:8080/littledevil/wxpay/getInvitationCode",
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      method: "POST",
      data: {
        salemanId: parseInt(userId)
      },
      success: (res) => {
       console.log(res)
        wx.showToast({
          title: '邀请码：' + res.data.InvitationCode,
          icon: 'none',
          duration: 1500,
          mask: true
        })
      }
    })
  },
  applyCompany: function () {
    wx.request({
      url: "http://127.0.0.1:8080/littledevil/wxpay/applyCompany",
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      method: "POST",
      data: {
        userId: parseInt(userId),
        invitationCode: 747642
      },
      success: (res) => {
        console.log(res)

      }
    })
  },
  memberConsume: function () {
    wx.request({
      url: "http://127.0.0.1:8080/littledevil/memberConsume/memberConsume",
      header: {
        //'content-type': 'application/x-www-form-urlencoded' // 默认值
        'content-type': 'application/json'
      },
      method: "POST",
      data: {
         companyMemberId: 1, 
         companyId: 2, 
         consumeCash: 2, 
         commodityId: 3, 
         isDelete: "0",
          userId: 4, 
          consumeNumber: 1, 
          payCash: 1, 
          consumeTime:""
      },
      success: (res) => {
        console.log(res)
      }
    })
  },
  memberRecharge: function () {
    wx.request({
      url: "http://127.0.0.1:8080/littledevil/memberRecharge/insertRecord",
      header: {
        //'content-type': 'application/x-www-form-urlencoded' // 默认值
        'content-type': 'application/json'
      },
      method: "POST",
      data: {
        companyMemberId: 12,
        companyId: 7,
        rechargeCash: 2,
        isDelete: "0",
        userId: 17,
        payCash: 1,
        rechargeTime: ""
      },
      success: (res) => {
        console.log(res)
      }
    })
  },
  getlocation: function () { //获取用户位置
    let that = this
    let lat = '',
      lng = ''
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        let latitude = res.latitude
        let longitude = res.longitude
        that.requestCityName(latitude, longitude);
      },
      fail: function (res) {
        let lat = '30.51597',
          lng = '114.34035';
        that.requestCityName(lat, lng);
      }
    })
  },
  requestCityName(lat, lng) { //获取当前城市
    app.globalData.userInfo.lat = lat
    app.globalData.userInfo.lng = lng
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + lat + "," + lng + "&key=4YFBZ-K7JH6-OYOS4-EIJ27-K473E-EUBV7",
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: (res) => {
        //this.getmoredata()        获取更多
        if (res.data.status == 0) {
          this.setData({
            city: res.data.result.address_component.city,
            alltopics: [],
            restaurant: [],
            service: []
          })
          app.globalData.userInfo.city = res.data.result.address_component.city
          app.globalData.picker = res.data.result.address_component
        }
      }
    })
  },
  getmoredata: function () { //获取更多数据
    this.getcarousel();
    this.getdata();
    this.getactlist();
    this.gethotlive();
    this.gettopic();
    this.gettoplistFor();
  }
 
})