import Api from '/../../../utils/config/api.js'
import { GLOBAL_API_DOMAIN } from '/../../../utils/config/config.js'
var utils = require('../../../utils/util.js')
var app = getApp()
Page({

  /** 
   * 页面的初始数据
   */
  data: {
    applied: false,
    isChecked:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 调用云函数,判断是否已经申请
    wx.cloud.callFunction({
      name: 'saleMan',
      data: {
        $url: 'getSaleMan',
        state:'0',
        id: app.globalData.id
      },
      success: res => {
        console.log(res);
        this.setData({
          applied: res.result.cont.data.length
        })
      },
      fail: err => {
        wx.showToast({
          title: '系统出错了哦！',
          duration: 2000
        })
      }
    })
    
  },
  formSubmit(){
    if (!this.data.isChecked) {
      wx.showToast({
        title: '请先同意协议才能申请',
        icon: 'none',
        mask: 'true',
        duration: 2000
      })}
    else{
      // 调用云函数,申请认证
      wx.cloud.callFunction({
        name: 'saleMan',
        data: {
          $url: 'applySaleMan',
          id: app.globalData.id
        },
        success: res => {
          console.log(res);
          wx.showToast({
            title: '认证成功！',
            duration: 2000
          })
          wx.switchTab({
            url: 'personal-center/personal-center',
          })
        },
        fail: err => {
          wx.showToast({
            title: '系统出错了哦！',
            duration: 2000
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this
    wx.getStorage({
      key: 'cate',
      success: function (res) {
        if (that.data.intype == 2) {
          that.setData({
            sortype: res.data
          })
        } else if (that.data.intype == 1) {
          that.setData({
            businessCate: res.data
          })
        }
      }
    })

  },
  checkboxChange: function (e) {
    if (e.detail.value==''){
      this.setData({
        isChecked: false
      })
    }
    else{
      this.setData({
        isChecked: true
      })
    }
   
  }
})