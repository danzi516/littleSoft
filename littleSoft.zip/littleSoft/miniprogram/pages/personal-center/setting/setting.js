var app = getApp();
Page({
	data: {
	},
	onLoad: function (options) {
		var that = this
	
	},
	
	onShow: function () {
		
	},
  getchooseLocation() {  //地图选点
    let that = this
    wx.navigateTo({
      url: '../free-of-charge/get-address/get-address?deaddress=' + that.data.deaddress
    })
  },
  openSetting(){
    var that = this
    console.log(111111111111)
     wx.openSetting({  //打开授权设置界面
                  success: (res) => {
                    console.log(3)
                    console.log(res)
                    if (res.authSetting['scope.userLocation']) {
                      console.log(4)
                      // that.getchooseLocation()
                      wx.navigateTo({
                        url: '../free-of-charge/free-of-charge'
                      })
                    }
                  }
                })
    // wx.getLocation({
    //   type: 'wgs84',
    //   success: function (res) {
    //     // console.log(res);
    //     var latitude = res.latitude
    //     var longitude = res.longitude
    //     //弹框
    //     wx.showModal({
    //       title: '当前位置',
    //       content: "纬度:" + latitude + ",经度:" + longitude,
    //     })
    //   }
    // })
   
  }
});