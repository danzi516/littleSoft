const app = getApp();
Page({
    data: {
      cateItems: [
        {
          child_id: 1,
          name: '西餐',
          checked: false
        },
        {
          child_id: 2,
          name: '中餐',
          checked: false
        },
        {
          child_id: 3,
          name: '越南',
          checked: false
        },
        {
          child_id: 4,
          name: '日本料理',
          checked: false
        },
        {
          child_id: 5,
          name: '美甲',
          checked: false
        },
        {
          child_id: 6,
          name: '美发',
          checked: false
        },
        {
          child_id: 7,
          name: '美容',
          checked: false
        },
        {
          child_id: 8,
          name: '台球',
          checked: false
        },
        {
          child_id: 9,
          name: '洗车',
          checked: false
        },
        {
          child_id: 10,
          name: '足疗',
          checked: false
        },
        {
          child_id: 11,
          name: '踩背',
          checked: false
        },
        {
          child_id: 12,
          name: '足球',
          checked: false
        },
        {
          child_id: 13,
          name: '篮球',
          checked: false
        }
        ],
      cateItemsList: [
        {
          id: 'a',
          classifyName: '餐饮',
          cateItems: [1,2,3,4]
        },
        {
          id: 'b',
          classifyName: '美妆',
          cateItems: [5,6,7]
        },
        {
          id: 'c',
          classifyName: '休闲/服务',
          cateItems: [8,9,10,11]
        },
        {
          id: 'd',
          classifyName: '运动',
          cateItems: [12,13]
        },

      ],
      cart: {
        count: 0,
        total: 0,
        list: {}
      },
      cartList: {},
      showCartDetail: false,
      value:0,
  },
  checkOrderSame: function (name) {
    var list = this.data.cateItems;
    for (var index in list) {
      if (list[index].name === name) {
        return index;
      }
    }
    return false;
  },
  onShow: function () {
    this.setData({
      classifySeleted: this.data.cateItemsList[0].id
    });
  },
  // tapAddCart: function (e) {
  //   this.addCart(e.target.dataset.id);
  // },
  // tapReduceCart: function (e) {
  //   this.reduceCart(e.target.dataset.id);
  // },
  // addCart: function (id) {
  //   var num = this.data.cart.list[id] || 0;
  //   this.data.cart.list[id] = num + 1;
  //   this.countCart();
  //   var price = this.data.cateItems[id].price;
  //   var name = this.data.cateItems[id].name;
  //   var img = this.data.cateItems[id].pic;
  //   var list = this.data.cartList;
  //   var sortedList = [];
  //   var index;
  //   if (index = this.checkOrderSame(name)) {
  //     sortedList = list[index];
  //     var num = this.data.cart.list[id] || 0;
  //     num = num + 1;
  //   }
  //   else {
  //     var order = {
  //       "price": price,
  //       "num": 1,
  //       "name": name,
  //       'img': img,
  //       "shopId": this.data.shopId,
  //       "shopName": this.data.shop.restaurant_name,
  //       "pay": 0,
  //     }
  //     list.push(order);

  //     sortedList = order;
  //   }
  //   this.setData({
  //     cartList: list,
  //   });
  //   console.log(list)
  // },
  // reduceCart: function (id) {
  //   var num = this.data.cart.list[id] || 0;
  //   if (num <= 1) {
  //     delete this.data.cart.list[id];
  //   } else {
  //     this.data.cart.list[id] = num - 1;
  //   }
  //   this.countCart();
  // },
  countCart: function (index, lists) {
    var count = 0,
      total = 0;
    var cateItems;
    for (var id in this.data.cart.list) {
      cateItems = this.data.cateItems[id];
      count += this.data.cart.list[id];
      total += cateItems.price * this.data.cart.list[id];
    }
    this.data.cart.count = count;
    this.data.cart.total = total;
    this.setData({
      cart: this.data.cart
    });
    // 存储订单页所需要的数据
    wx.setStorage({
      key: 'orderList',
      data: {
        count: this.data.cart.count,
        total: this.data.cart.total,
        list: this.data.cart.list,
      }
    })

  },
  follow: function () {
    this.setData({
      followed: !this.data.followed
    });
  },
  oncateItemsScroll: function (e) {
    if (e.detail.scrollTop > 10 && !this.data.scrollDown) {
      this.setData({
        scrollDown: true
      });
    } else if (e.detail.scrollTop < 10 && this.data.scrollDown) {
      this.setData({
        scrollDown: false
      });
    }

    var scale = e.detail.scrollWidth / 570,
      scrollTop = e.detail.scrollTop / scale,
      h = 0,
      classifySeleted,
      len = this.data.cateItemsList.length;
    this.data.cateItemsList.forEach(function (classify, i) {
      var _h = 70 + classify.cateItems.length * (46 * 3 + 20 * 2);
      if (scrollTop >= h - 100 / scale) {
        classifySeleted = classify.id;
      }
      h += _h;
    });
    this.setData({
      classifySeleted: classifySeleted
    });
  },
  tapClassify: function (e) {
    var id = e.currentTarget.dataset.id;
    this.setData({
      classifyViewed: id
    });
    var self = this;
    setTimeout(function () {
      self.setData({
        classifySeleted: id
      });
    }, 100);
  },
  showCartDetail: function () {
    this.setData({
      showCartDetail: !this.data.showCartDetail
    });
  },
  hideCartDetail: function () {
    this.setData({
      showCartDetail: false
    });
  },
  submit: function (e) {
    let checkNum = this.data.value.length
    if (checkNum>3){
      wx.showToast({
        title: '最多选择3个分类,请先取消再选择',
        mask: true,
        icon: 'none',
        duration: 2000
      })
    }
    else{
    // wx.navigateTo({
    //   url: '../free-of-charge/free-of-charge?category=' + this.data.value
    // })
      let pages = getCurrentPages();//当前页面    （pages就是获取的当前页面的JS里面所有pages的信息）
      let prevPage = pages[pages.length - 2]
      prevPage.setData({
        businessCate: this.data.value,
      })
      wx.navigateBack({
        delta: 1
      })
    }
    // var agrs = JSON.stringify(this.data.cart);
    // console.log(agrs)
    // wx.navigateTo({
    //   url: '../order/order?order=' + agrs
    // })
  },
  checkboxChange(e) {
    let _value = e.detail.value
    console.log(e)
    this.data.value = _value
  }
})  
