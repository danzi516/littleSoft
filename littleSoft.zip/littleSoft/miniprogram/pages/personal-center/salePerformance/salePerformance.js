const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title: '加载中...', // 状态
    list: [], // 数据列表
    type: '', // 数据类型
    loading: true // 显示等待框
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) { // options 为 board页传来的参数
    const _this = this;
    //请求数据
    //获取商家信息
    wx.cloud.callFunction({
      name: 'saleMan',
      data: {
        $url: 'getSaleManCompany',
        id: app.globalData.id
      }
    }).then(res => {
      console.log(res.result)
      this.setData({
        tabIndex: 0,
        title:'',
        newGoods: res.result.cont.data,
        apiStatus: this.data.apiStatus + 1,
        resBaseUrl: app.globalData.bastUrl,
        loading:false
      });
      
    }).catch(err => {
      console.log(err)
    })
    // 拼接请求url
    //const url = 'https://api.douban.com/v2/movie/' + options.type;
    //const url = 'https://api.douban.com/v2/movie/in_theaters'
      // 请求数据
      // wx.request({
      //   url: url,
      //   header: {
      //     'content-type': 'json' // 默认值
      //   },
      //   success: function (res) {
      //     console.log(res.data);
      //     // 赋值
      //     _this.setData({
      //       title: res.data.title,
      //       list: res.data.subjects,
      //       type: options.type,
      //       loading: false // 关闭等待框
      //     })
      //   }
      // })
  },
  getInvitationCode(){
    this.setData({
      loading: true
    })
    //获取邀请码
    wx.cloud.callFunction({
      name: 'saleMan',
      data: {
        $url: 'getInvitationCode',
        id: app.globalData.id
      }
    }).then(res => {
      this.setData({
        loading: false
      })
      console.log(res.result.cont.data[0].invitation_code)
      wx.showToast({
        title: '邀请码：' + res.result.cont.data[0].invitation_code,
        icon: 'none',
        duration: 3000
      })
    }).catch(err => {
      console.log(err)
    })
  }
})