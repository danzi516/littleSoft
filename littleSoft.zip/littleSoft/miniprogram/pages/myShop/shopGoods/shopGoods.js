var app = getApp()
Page({

  data: {
    title: '加载中...', // 状态
    loading: true, // 显示等待框
    id:'',//店铺id
    isChecked:false,
    shop:{},  //店铺
    index:'',
    userList: '',
  },
 
  onLoad: function (options) {
    let shopId = app.globalData.shopList[options.index].id
    if (app.globalData.shopList[options.index].memberConfirm=='1'){
      this.setData({
        isChecked:true
      })
    }
    this.setData({
      id: shopId,
      userId: app.globalData.id,
      index: options.index,
      shop: app.globalData.shopList[options.index]
    })
    wx.cloud.callFunction({
      name: 'companyMember',
      data: {
        $url: 'getShopMember',
        id: this.data.id
      }
    }).then(res => {
      console.log(res.result)
      this.setData({
        userList: res.result.cont.data
      })
    })
  },
  changeSwitch(e) {
    this.data.memberConfirm = "0"
    let _value = e.detail.value
    if (_value) {
      this.data.memberConfirm = "1"
    }
    wx.cloud.callFunction({
      name: 'companyInfo',
      data: {
        $url: 'updateCompany',
        data: {
          id: this.data.id,
          memberConfirm: this.data.memberConfirm
        }
      }
    }).then(res => {
      console.log(res.result)
      this.data.shop.memberConfirm = this.data.memberConfirm
      app.globalData.shopList[this.data.index] = this.data.shop
    }).catch(err => {
      console.log(err)
    })
  },
})