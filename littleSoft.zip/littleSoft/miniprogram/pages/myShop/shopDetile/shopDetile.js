var app = getApp()
Page({

  data: {
    title: '加载中...', // 状态
    loading: true, // 显示等待框
    id:'',//店铺id
    isChecked:false,
    shop:{}//店铺
  },
 
  onLoad: function (options) {
    //console.log(options)
    let object = JSON.parse(options.shopInfo);
    if (object.memberConfirm=='1'){
      this.setData({
        isChecked: true,
        id: object.id,
        shop: object
      })
    }
  },
  changeSwitch(e){
    this.data.memberConfirm = "0"
    let _value = e.detail.value
    if (_value){
      this.data.memberConfirm = "1"
    }
    wx.cloud.callFunction({
      name: 'companyInfo',
      data: {
        $url: 'updateCompany',
        data:{
          id: this.data.shop.id,
          memberConfirm: this.data.memberConfirm
        }
      }
    }).then(res => {
      console.log(res.result)

    }).catch(err => {
      console.log(err)
    })
  },
  shopMember(){
    wx.navigateTo({
      url: 'free-of-charge/free-of-charge',
    })
  }
})