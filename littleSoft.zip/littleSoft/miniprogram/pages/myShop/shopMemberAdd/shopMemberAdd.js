var app = getApp()
Page({

  data: {
    title: '加载中...', // 状态
    loading: true, // 显示等待框
    id:'',//店铺id
    isChecked:false,
    shop:{},  //店铺
    index:'',
    loading: false, // 显示等待框
    userList:'',
    logo:'',
    userId:'',
  },
 
  onLoad: function (options) {
    let shopId = options.id
    this.setData({
      id : shopId,
      userId: app.globalData.id
    })

  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    // getList(this);
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    // getList(this);
  },
  inputTyping: function (e) {
    //搜索数据
    // getList(this, e.detail.value);
    this.setData({
      inputVal: e.detail.value
    });
  },
  searchUser(e){
    let keyword = e.detail.value
    if (keyword==''){
      wx.showToast({
        title: '请输入查询数据',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    this.setData({
      loading: true})
    //获取申请的店铺信息
    wx.cloud.callFunction({
      name: 'user',
      data: {
        $url: 'getUserByKey',
        keyword: keyword
      }
    }).then(res => {
      console.log(res.result)
      this.setData({
        userList: res.result.userList.data
      })
      this.setData({
        loading: false,
        logo:''
      })
      console.log(this.data.logo)
    }).catch(err => {
      console.log(err)
    })
  },
  addShopMember(e){
    this.setData({
      loading: true
    })
    let userId =e.currentTarget.dataset.id 
    let membership_card = e.currentTarget.dataset.membership_card
    wx.cloud.callFunction({
      name: 'companyMember',
      data: {
        $url: 'addShopMember',
        id: this.data.id,
        userId: userId,
        membership_card: membership_card
      }
    }).then(res => {
      console.log(res.result)
      this.setData({
        loading: false
      })
      let code = res.result.code
      if (code==1){
        wx.showToast({
          title: '该用户已经是会员',
          icon: 'none',
          duration: 2000
        })
      }
      else {
        wx.showToast({
          title: '添加成功',
          icon: 'none',
          duration: 2000
        })}
      }).catch(err => {
        console.log(err)
      })
  },
})