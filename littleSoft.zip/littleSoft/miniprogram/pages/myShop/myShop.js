var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentData: 0,
    title: '加载中...', // 状态
    list: [], // 数据列表
    type: '', // 数据类型
    loading: true, // 显示等待框
    totable: '',
    shopList:[],
    shopShortNameList:[],
    shopIndex:0,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  //获取当前滑块的index
  bindchange: function (e) {
    const that = this;
    that.setData({
      currentData: e.detail.current
    })
    if (e.detail.current==0){
      //获取加入的店
    }
    else{
      //获取申请的店铺信息
      wx.cloud.callFunction({
        name: 'companyInfo',
        data: {
          $url: 'selectCompanyAllList',
          userId: app.globalData.id
        }
      }).then(res => {
        console.log(res.result)
        if (res.result.cont.data.length > 0) {
          app.globalData.shopList = res.result.cont.data
          this.setData({
            title: '',
            //newGoods: res.result.cont.data,
            shopList: res.result.cont.data,
            shopShortNameList: res.result.shortName.data,
            apiStatus: this.data.apiStatus + 1,
            resBaseUrl: app.globalData.bastUrl,
            loading: false,
            totable: false
          });
        }
        else {
          this.setData({
            title: '',
            totable: true
          });}

      }).catch(err => {
        console.log(err)
      })
    }
  },
  //点击切换，滑块index赋值
  checkCurrent: function (e) {
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {

      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },

  bindPickerChange(e){
    console.log(e)

  },





  shopDetile(e){
    console.log(e)
    if(e.currentTarget.dataset.isstate=='0'){
      wx.showToast({
        title: '请先去激活!',
        mask: true,
        icon: 'none',
        duration: 2000
      })
    }
    else{
      console.log(e.currentTarget.dataset.shopinfo)
      let shopinfo = JSON.stringify(e.currentTarget.dataset.shopinfo);
      wx.navigateTo({
        url: 'shopDetile/shopDetile?shopInfo=' + shopinfo
      })
    }
  },
  shopMember(e){
    //let shopInfo = this.data.shopList[this.data.shopIndex]
    wx.navigateTo({
      url: 'shopMember/shopMember?index=' + this.data.shopIndex
    })
  },
})