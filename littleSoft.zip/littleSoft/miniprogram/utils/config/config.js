
var BASEURL = "http://127.0.0.1:8080/littledevil/";  //正式服务器
// var BASEURL =  "https://www.xq0036.top/";  //测试服务器

var config = {
  GLOBAL_API_DOMAIN: BASEURL
};
module.exports = config;